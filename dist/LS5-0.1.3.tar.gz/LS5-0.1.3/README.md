# ls5: A Simple Web Scraper using Selenium that takes external args

`ls5` is a command-line tool built with Selenium to scrape all links from a given webpage. You provide the URL as an argument, and the tool will fetch and display all the links present on that page. It runs headlessly (no GUI needed), making it efficient for automation.

## Features

- Scrapes all links (`<a>` tags) from the provided webpage URL.
- Works in headless mode to avoid opening the browser window.
- Simple to use with just a single command and URL input.

## Requirements

- Python 3.6 or higher
- Selenium 4.10.0
- Webdriver Manager 3.8.6
- Google Chrome and Chromedriver installed version ChromeDriver 126.0.6478.126 (d36ace6122e0a59570e258d82441395206d60e1c-refs/branch-heads/6478@{#1591})  

## Installation

1. Install the package from PyPI:

    ```bash
    pip install ls5
    ```

2. Make sure you have `Google Chrome` and `Chromedriver` installed and accessible in your environment,
at the location if the path in your script.

## Usage

To scrape links from a webpage, use the following command:

or
```
ls5 --url
